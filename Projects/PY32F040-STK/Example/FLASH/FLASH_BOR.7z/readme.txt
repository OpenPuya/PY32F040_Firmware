================================================================================
                                样例使用说明
                             Sample Description
================================================================================
功能描述：
此样例演示了修改FLASH的BOR功能。

Function descriptions:
This example demonstrates the BOR function of modifying FLASH.
================================================================================
测试环境：
测试用板：PY32F040_STK
MDK版本： 5.28
IAR版本： 9.20
GCC 版本：GNU Arm Embedded Toolchain 10.3-2021.10

Test environment:
Test board: PY32F040_STK
MDK Version: 5.28
IAR Version: 9.20
GCC Version: GNU Arm Embedded Toolchain 10.3-2021.10

================================================================================
使用步骤：
1. 编译并下载程序；
2. 程序将BOR设置为2.3V/2.4V,设置成功，LED灯被点亮

Example execution steps:
1. Compile and download the program;
2. The program sets BOR to 2.3V/2.4V, and the setting is successful. The LED
light is turned on.
================================================================================
注意事项：

Notes:

================================================================================